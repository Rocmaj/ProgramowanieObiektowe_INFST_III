public class BankAccount_Lab {
    public static class BankAccount {
        private double balance;

        public void deposit(double kwota) {
            if (kwota > 0) {
                this.balance += kwota;
                System.out.println("Deposited: "+ kwota);
            } else {
                System.out.println("Balance must be higher than 0!");
            }
        }

        public void withdraw(double kwota) {
            if (kwota > 0 && kwota <= balance) {
                this.balance -= kwota;
                System.out.println("Withdrawn: " + kwota);
            } else {
                System.out.println("No funds available or wrong number inputted");
            }
        }

        public double getBalance() {
            return balance;
        }

        public static void main(String[] args) {
            BankAccount account = new BankAccount();
            account.deposit(242.45);
            account.withdraw(12.34);
            System.out.println("Balance: "+ account.getBalance());
            account.withdraw(999.99);
            account.deposit(-199.99);

        }

    }

}
