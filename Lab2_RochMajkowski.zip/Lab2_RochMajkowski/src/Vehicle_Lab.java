public class Vehicle_Lab {
    public static class Vehicle {
        String marka;
        int rok_produkcji;

        Vehicle(String marka, int rok_produkcji){
            this.marka = marka;
            this.rok_produkcji = rok_produkcji;
        }

        void getDescription() {
            System.out.println(
                            "Marka: "+ marka +"\n" +
                            "Rok produkcji: "+ rok_produkcji +"\n");
        }

        static class Car extends Vehicle {
            int liczba_drzwi;
            Car(String marka, int rok_produkcji, int liczba_drzwi) {
                super(marka, rok_produkcji);
                this.liczba_drzwi = liczba_drzwi;
            }

            @Override
            void getDescription() {
                System.out.println(
                                "Marka: "+ marka +"\n" +
                                "Rok produkcji: "+ rok_produkcji +"\n" +
                                "Liczba drzwi: "+ liczba_drzwi + "\n"); // Element jest ekskluzywny dla klasy Car
            }

        }

        public static void main(String[] args) {
            Vehicle vehicle = new Vehicle("Volkswagen",1987);
            vehicle.getDescription();
            Car car = new Car("Toyota", 2006, 5);
            car.getDescription();
        }

    }
}
