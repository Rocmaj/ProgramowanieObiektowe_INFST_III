public class Book_Lab {

    public static class Book {
        private String title;
        private String author;
        private Boolean available = true;

        public Book(String title, String author) {
            this.title = title;
            this.author = author;
        }

        public String getTitle() {
            return title;
    }
        public String getAuthor() {
            return author;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public void Borrow(){
            if(available!=false) {
                available = false;
                System.out.println("Wypożyczyłeś ksiązkę " + title + ", autorstwa " + author);
            } else {
                System.out.println("Książka jest już wypożyczona");
            }
        }

        public void ReturnBook(){
            if (available!=true) {
                available = true;
                System.out.println("Zwróciłeś ksiązkę " + title + ", autorstwa " + author);
            } else {
                System.out.println("Ksiązka nie została wypożyczona");
            }
        }

        @Override
        public String toString(){
            return "Book{title= '" + title + "', author=" + author + "}";
        }
        public static void main(String[] args) {
            Book book = new Book("Pan Tadeusz","Adam Mickwiecz");
            Book book1 = new Book("ABC", "xyz");
            System.out.println(book);
            book.Borrow();
            book.Borrow();

            System.out.println("///////////////////// KSIAZKA 2 //////////////////");
            System.out.println(book1);
            book1.ReturnBook();
            book1.Borrow();
            book1.ReturnBook();
            book1.setAuthor("Jan Kowalski");
            System.out.println(book1);
        }

    }
}