public class ElectricCar_Lab {
    public static class Vehicle {
        String marka;
        int rok_produkcji;

        Vehicle(String marka, int rok_produkcji){
            this.marka = marka;
            this.rok_produkcji = rok_produkcji;
        }

        void getDescription() {
            System.out.println(
                            "Marka: "+ marka +"\n" +
                            "Rok produkcji: "+ rok_produkcji +"\n");
        }

        static class ElectricCar extends Vehicle {
            int pojemnosc_baterii;
            ElectricCar(String marka, int rok_produkcji, int pojemnosc_baterii) {
                super(marka, rok_produkcji);
                this.pojemnosc_baterii = pojemnosc_baterii;
            }

            @Override
            void getDescription() {
                System.out.println(
                                "Marka: "+ marka +"\n" +
                                "Rok produkcji: "+ rok_produkcji +"\n" +
                                "Liczba drzwi: "+ pojemnosc_baterii + "\n"); // Element jest ekskluzywny dla klasy ElectricCar
            }

        }

        static class Car extends Vehicle {
            int liczba_drzwi;
            Car(String marka, int rok_produkcji, int liczba_drzwi) {
                super(marka, rok_produkcji);
                this.liczba_drzwi = liczba_drzwi;
            }

            @Override
            void getDescription() {
                System.out.println(
                                "Marka: "+ marka +"\n" +
                                "Rok produkcji: "+ rok_produkcji +"\n" +
                                "Liczba drzwi: "+ liczba_drzwi + "\n"); // Element jest ekskluzywny dla klasy Car
            }

        }

        public static void main(String[] args) {
            Vehicle[] vehicles = {
                    new ElectricCar("Hyundai", 2023, 30),
                    new Car("Volkswagen", 2014, 3)
            };

            for(Vehicle vehicle : vehicles) {
                vehicle.getDescription();
            }
        }
    }
}

