package ImmutableColor;

public final class ImmutableColor {
    final int r;
    final int g;
    final int b;

    public ImmutableColor(int r, int g, int b) {
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public final void describe() {
        System.out.println("RGB (" + r + ", " + g + ", " + b + ")");
    }
}
