package ImmutableColor;

public class Main {
    public static void main(String[] args) {
        ImmutableColor red = new ImmutableColor(255, 0, 0);
        red.describe();

        // Próba utworzenia podklasy klasy ImmutableColor i nadpisania metody describe():



        /*
        class MyColor extends ImmutableColor {
            public MyColor(int r, int g, int b) {
                super(r,g,b);
            }

            @Override
            public void describe() {
                System.out.println("Nowy opis");
            }
        }
        */



        //Błąd kompilacji : java: cannot inherit from final ImmutableColor.ImmutableColor

    }
}
