package Eksperyment;

public class Counter {
    String name;
    int value;

    static int obiekty = 0;

    public Counter(String name, int value){
        this.name = name;
        this.value = value;
        Counter.obiekty++;
    }

    public void printInfo(){
        System.out.println(name + " -> wartość: " + value + ", ilość obiektów: " + obiekty);
    }
}
