package Eksperyment;

public class Main {
    public static void main(String[] args) {
        Counter c1 = new Counter("c1", 10);
        Counter c2 = new Counter("c2", 20);
        Counter c3 = new Counter("c3", 30);

        // Przed zmianą wartości - wywołanie

        c1.printInfo();
        c2.printInfo();
        c3.printInfo();

        // Zmiana dla c1

        c1. value = 256;

        // Po zmianie c1 = 256;

        c1.printInfo();
        c2.printInfo();
        c3.printInfo();

        // Zmiana pola liczenia obiektow

        Counter.obiekty = 100;

        //Po zmainie wszystkich obiektow jest 100

        c1.printInfo();
        c2.printInfo();
        c3.printInfo();


    }
}
