package Product;
public class Main {
    public static void main(String[] args) {
        Product product1 = new Product("Computer", 1099.99, "Hardware", true); // Product Nr. 1
        Product product2 = new Product("Limited Edition T-Shirt", 29.99, "Apparel", false); // Product Nr. 2

        product1.printInfo();
        product2.printInfo();
    }
}