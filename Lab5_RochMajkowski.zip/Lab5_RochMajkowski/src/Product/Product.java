package Product;
public class Product {
    String name;
    double price;
    String category;
    boolean available;

    static int productCount = 0;

    public Product(String name, double price, String category, boolean available){
        this.name = name;
        this.price = price;
        this.category = category;
        this.available = available;
    }


    public void printInfo() {

        Product.productCount++; // Zwiększenie numeru produktu o 1

        System.out.println( "Name: " + name +
                            "\nPrice: " + price +
                            "\nCategory: " + category +
                            "\nAvailable: " + available +
                            "\nProduct Nr. " + productCount + "\n"
                            );

    }
}
