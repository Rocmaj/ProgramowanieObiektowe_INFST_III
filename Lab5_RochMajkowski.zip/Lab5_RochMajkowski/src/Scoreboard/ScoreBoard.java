package Scoreboard;

import Product.Product;

public class ScoreBoard {
    String teamA;
    String teamB;
    int teamA_score;
    int teamB_score;
    static int playedMatches;

    public ScoreBoard(String teamA, String teamB, int teamA_score, int teamB_score) {
        this.teamA = teamA;
        this.teamB = teamB;
        this.teamA_score = teamA_score;
        this.teamB_score = teamB_score;
    }

    public void printMatchHistory() {

        ScoreBoard.playedMatches++; // Zwiększenie numeru meczy o 1

        if (teamA_score > teamB_score){
            System.out.println("\nTeam "+ teamA + " has won the game against "+ teamB +", with a score of "+teamA_score+"-"+teamB_score+"; Congratulations!\n" +
                    "Match Nr." + playedMatches + ", "+ teamA +" vs. "+ teamB + "\n");
        }

        else if (teamA_score < teamB_score){
            System.out.println("\nTeam "+ teamB + " has won the game against "+ teamA +", with a score of "+teamB_score+"-"+teamA_score+"; Congratulations!\n" +
                    "Match Nr." + playedMatches + ", "+ teamA +" vs. "+ teamB + "\n");
        }

        else {
            System.out.println("\nIt's a tie!\n" +
                    "Match Nr." + playedMatches + ", "+ teamA +" vs. "+ teamB + "\n");
        }

    }


}
