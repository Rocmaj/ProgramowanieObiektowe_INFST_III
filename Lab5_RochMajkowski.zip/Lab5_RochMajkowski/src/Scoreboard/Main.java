package Scoreboard;

public class Main {
    public static void main(String[] args) {
        ScoreBoard scoreBoard = new ScoreBoard("Blekitni", "Gryf", 3, 5);
        ScoreBoard scoreBoard1 = new ScoreBoard("Strikers", "Keepers", 8, 1);
        ScoreBoard scoreBoard2 = new ScoreBoard("Ying", "Yang", 2, 2);
        scoreBoard.printMatchHistory();
        scoreBoard1.printMatchHistory();
        scoreBoard2.printMatchHistory();
    }
}
