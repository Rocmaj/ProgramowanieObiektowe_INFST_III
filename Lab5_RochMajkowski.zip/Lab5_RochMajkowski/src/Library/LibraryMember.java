package Library;

public class LibraryMember {
    final int memberId;
    String name;
    boolean isRenting;

    public LibraryMember(int memberId, String name, boolean isRenting){
        this.memberId = memberId;
        this.name = name;
        this.isRenting = isRenting;
    }

    public void memberInfo() {
        System.out.println(
                            "\nId: " + memberId +
                            "\nName: " + name +
                            "\nRenting: " + isRenting
        );
    }
}
