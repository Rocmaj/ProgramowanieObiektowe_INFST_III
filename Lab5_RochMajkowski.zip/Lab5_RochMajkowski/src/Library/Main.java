package Library;

public class Main {
    public static void main(String[] args) {
        LibraryMember libraryMember = new LibraryMember(1, "Jan Kowalski", true);
        libraryMember.memberInfo();
        // libraryMember.memberId = 2; // Błąd : java: cannot assign a value to final variable memberId

    }
}
