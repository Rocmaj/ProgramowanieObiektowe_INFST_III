package Visitor;

public class VisitCounter {
    int visited;

    public void counter() {

        for (int x=0; x<5; x++) {

            int localVisited = 0;
            localVisited++; // Inkrementacja lokalnej
            visited++; // Inkrementacja globalnej

            System.out.println("\nWizyta lokalna: " + localVisited +
                    "\nWizyta globalna: " + visited);
        }

    }
}
