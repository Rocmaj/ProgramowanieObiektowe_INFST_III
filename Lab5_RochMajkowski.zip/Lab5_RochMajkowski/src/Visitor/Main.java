package Visitor;

public class Main {
    public static void main(String[] args) {
        VisitCounter visitCounter = new VisitCounter();
        visitCounter.counter();
    }
}
